/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 80019
Source Host           : localhost:3306
Source Database       : twt

Target Server Type    : MYSQL
Target Server Version : 80019
File Encoding         : 65001

Date: 2022-12-08 01:14:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `commodity`
-- ----------------------------
DROP TABLE IF EXISTS `commodity`;
CREATE TABLE `commodity` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `manufacturer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '制造商',
  `producttime` datetime DEFAULT NULL COMMENT '生产时间',
  `stock` int DEFAULT NULL COMMENT '库存',
  `price` float DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `eid` int DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE,
  KEY `eid` (`eid`) USING BTREE,
  CONSTRAINT `eid` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of commodity
-- ----------------------------
INSERT INTO `commodity` VALUES ('1', '铁观音', '本产品产自安溪', '历史集团', '2022-11-17 10:56:59', '111', '112', '1.jpg', '16', '10001');
INSERT INTO `commodity` VALUES ('2', '大红袍', null, '望龙企业', '2022-11-17 00:17:28', '999', '89', null, '17', '10001');
INSERT INTO `commodity` VALUES ('3', '绿茶', null, '望龙企业', '2022-11-17 00:19:28', '999', '22', null, '15', '10001');
INSERT INTO `commodity` VALUES ('4', '红茶', null, '望龙企业', '2022-11-17 00:21:34', '999', '23', null, '16', '10001');

-- ----------------------------
-- Table structure for `corder`
-- ----------------------------
DROP TABLE IF EXISTS `corder`;
CREATE TABLE `corder` (
  `oid` int NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `pname` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `uid` int DEFAULT NULL,
  `store` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `teaname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `saddress` varchar(155) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`oid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of corder
-- ----------------------------
INSERT INTO `corder` VALUES ('202211150', '8.00', '7月谢谢茶园大丰收现发布好茶100份先到先得拼好发货', '张三', '广东省广州市海珠区新港中路397号', '020-81167888', '2022111703', '望龙企业', '大红袍', '1号茶场2号厂房');
INSERT INTO `corder` VALUES ('202211151', '889.00', '5月鞋添号茶场发布好茶', '张三', '广东省广州市海珠区新港中路397号', '020-81167888', '2022111703', '历史集团', '铁观音', '福州永泰');

-- ----------------------------
-- Table structure for `coupon`
-- ----------------------------
DROP TABLE IF EXISTS `coupon`;
CREATE TABLE `coupon` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `couponType` int DEFAULT NULL,
  `couponState` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `total` int DEFAULT NULL,
  `uid` int DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `deduction` int DEFAULT NULL,
  `condition` int DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `eid` int DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE,
  KEY `eid2` (`eid`) USING BTREE,
  CONSTRAINT `eid2` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of coupon
-- ----------------------------
INSERT INTO `coupon` VALUES ('1', '11', '25', '谢氏集团大茶场5折卷', '96', '2022111702', null, '0.50', '0', '400', '2022-11-14 11:40:41', '2022-11-17 11:40:46', '10001');
INSERT INTO `coupon` VALUES ('2', '12', '25', '谢谢工会茶庄满300减40卷', '99', '2022111702', null, '0.00', '40', '300', '2022-11-14 11:40:49', '2022-11-26 11:40:51', '10002');
INSERT INTO `coupon` VALUES ('3', '12', '25', '好茶卷', '219', '2022111702', null, '0.00', '20', '0', '2022-11-17 22:16:55', '2022-12-08 22:16:58', '10001');

-- ----------------------------
-- Table structure for `couponlog`
-- ----------------------------
DROP TABLE IF EXISTS `couponlog`;
CREATE TABLE `couponlog` (
  `clid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `uid` int DEFAULT NULL,
  `inserttime` datetime DEFAULT NULL,
  `cid` int NOT NULL,
  PRIMARY KEY (`clid`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of couponlog
-- ----------------------------
INSERT INTO `couponlog` VALUES ('1', '谢氏集团大茶场5折卷', '2022111701', '2022-12-07 17:34:10', '1');
INSERT INTO `couponlog` VALUES ('2', '谢氏集团大茶场5折卷', '2022111702', '2022-12-07 10:09:07', '1');
INSERT INTO `couponlog` VALUES ('3', '谢氏集团大茶场5折卷', '2022111703', '2022-12-07 10:23:32', '1');
INSERT INTO `couponlog` VALUES ('4', '谢谢工会茶庄满300减40卷', '2022111702', '2022-12-07 10:47:51', '2');
INSERT INTO `couponlog` VALUES ('5', '好茶卷', '2022111702', '2022-12-07 10:47:54', '3');

-- ----------------------------
-- Table structure for `enterprise`
-- ----------------------------
DROP TABLE IF EXISTS `enterprise`;
CREATE TABLE `enterprise` (
  `eid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `telephone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`eid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10003 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of enterprise
-- ----------------------------
INSERT INTO `enterprise` VALUES ('10001', '历史集团', '我们公司好', '12345678910');
INSERT INTO `enterprise` VALUES ('10002', '望龙企业', '我们的公司正在蒸蒸日上睨', '01987654321');

-- ----------------------------
-- Table structure for `order`
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `oid` int NOT NULL AUTO_INCREMENT,
  `money` decimal(10,2) DEFAULT NULL,
  `harvestAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `consignee` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `payState` int DEFAULT NULL,
  `uid` int DEFAULT NULL,
  `orderState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `eid` int DEFAULT NULL,
  `payment` decimal(10,2) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `Trade_name` varchar(255) DEFAULT NULL,
  `store` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`oid`) USING BTREE,
  KEY `eo` (`eid`) USING BTREE,
  CONSTRAINT `eo` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=221114058 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('221114039', '201.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '201.00', '2022-12-07 03:46:29', '望龙企业', '望龙企业');
INSERT INTO `order` VALUES ('221114040', '201.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '201.00', '2022-12-07 03:51:46', '望龙企业', '望龙企业');
INSERT INTO `order` VALUES ('221114041', '23.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '23.00', '2022-12-07 03:54:11', '望龙企业', '望龙企业');
INSERT INTO `order` VALUES ('221114042', '598.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '299.00', '2022-12-07 04:15:39', '望龙企业', '望龙企业');
INSERT INTO `order` VALUES ('221114043', '224.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '224.00', '2022-12-07 08:34:21', '望龙企业', '望龙企业');
INSERT INTO `order` VALUES ('221114044', '112.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '112.00', '2022-12-07 10:52:27', '历史集团', '历史集团');
INSERT INTO `order` VALUES ('221114046', '437.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '229.50', '2022-12-07 11:23:23', '历史集团', '历史集团');
INSERT INTO `order` VALUES ('221114047', '437.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10002', '229.50', '2022-12-07 11:23:25', '历史集团', '历史集团');
INSERT INTO `order` VALUES ('221114052', '154.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10001', '154.00', '2022-12-07 15:27:21', null, '望龙企业');
INSERT INTO `order` VALUES ('221114054', '572.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10001', '286.00', '2022-12-07 15:35:46', null, '望龙企业');
INSERT INTO `order` VALUES ('221114057', '112.00', '广东省广州市海珠区新港中路397号', '张三', '020-81167888', '13', '2022111702', '7', '10001', '112.00', '2022-12-07 15:50:20', null, '历史集团');

-- ----------------------------
-- Table structure for `orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oid` int DEFAULT NULL,
  `tid` int DEFAULT NULL,
  `pid` int DEFAULT NULL,
  `cid` int DEFAULT NULL,
  `coupon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `buynum` int DEFAULT NULL,
  `buyprice` decimal(10,2) DEFAULT NULL,
  `uid` int DEFAULT NULL,
  `eid` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `eoi` (`eid`) USING BTREE,
  CONSTRAINT `eoi` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('1', '221114038', null, null, '1', null, '1', '8.00', '22111201', '10001');
INSERT INTO `orderitem` VALUES ('2', '221114001', null, null, '1', null, '1', '8.00', '22111201', '10002');

-- ----------------------------
-- Table structure for `phc`
-- ----------------------------
DROP TABLE IF EXISTS `phc`;
CREATE TABLE `phc` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `total` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `state` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `eid` int DEFAULT NULL,
  `ulist` int DEFAULT NULL,
  `totalPeople` int DEFAULT NULL,
  `store` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `ep` (`eid`) USING BTREE,
  CONSTRAINT `ep` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=202211153 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of phc
-- ----------------------------
INSERT INTO `phc` VALUES ('202211150', '7月谢谢茶园大丰收现发布好茶100份先到先得拼好发货', 'AAAAA茶叶先到先得', '8.00', '444', '84', '1号茶场2号厂房', '2022-11-14 09:00:00', '2022-11-14 11:50:00', '2022-11-14 09:00:14', '3', 'images/1.png', '15', '10001', '2022111701', '100', '望龙企业', '大红袍');
INSERT INTO `phc` VALUES ('202211151', '5月鞋添号茶场发布好茶', '特产乌龙茶', '889.00', '555', '53', '福州永泰', '2022-11-16 06:56:25', '2022-12-23 06:56:28', '2022-11-17 09:30:56', '5', 'images/4.jpg', '16', '10002', '2022111701', '200', '历史集团', '铁观音');
INSERT INTO `phc` VALUES ('202211152', '新年红茶预定', '限量200份先到先得', '300.00', '200', '10', '福建生产', '2022-11-17 02:31:30', '2022-12-02 02:31:33', '2022-11-17 10:41:02', '3', 'images/1.jpg', '1', '10001', '2022111701', '10', '鑫哥传媒', '绿茶');

-- ----------------------------
-- Table structure for `travel`
-- ----------------------------
DROP TABLE IF EXISTS `travel`;
CREATE TABLE `travel` (
  `tid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int unsigned DEFAULT '0',
  `total` int DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `state` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `eid` int DEFAULT NULL,
  PRIMARY KEY (`tid`) USING BTREE,
  KEY `eid` (`eid`) USING BTREE,
  CONSTRAINT `et` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=202211157 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of travel
-- ----------------------------
INSERT INTO `travel` VALUES ('202211150', '1号茶场14日上午观光游', '由茶场负责人带领游客参观本企业生产茶叶的流程。', '8.00', '0', '83', '1号茶场2号厂房', '2022-11-14 09:00:00', '2022-11-14 11:50:00', '2022-11-14 09:00:14', '4', 'images/2.jpg', '1', '10001');
INSERT INTO `travel` VALUES ('202211151', '2号茶场欢迎你', '带领游客参观茶场', '80.00', '0', '50', '鞋收丰泽区分厂', '2022-11-16 10:44:00', '2022-11-23 10:44:00', '2022-11-16 15:24:48', '4', 'images/3.jpg', '2', '10002');
INSERT INTO `travel` VALUES ('202211152', '3号茶场', '22', '22.00', '0', '24', '安溪', '2022-11-16 21:17:50', '2022-12-01 21:17:53', '2022-11-16 21:20:10', '4', 'images/123.jpg', '1', '10002');
INSERT INTO `travel` VALUES ('202211153', '4号茶场', '333', '233.00', '0', '32', '福建', '2022-11-16 21:32:01', '2022-12-23 21:32:04', '2022-11-16 21:32:23', '3', 'images/133.jpg', '1', '10002');
INSERT INTO `travel` VALUES ('202211154', '5号茶场', '221', '23.00', '0', '132', '晋江', '2022-11-16 21:37:49', '2022-11-30 21:37:52', '2022-11-16 21:40:09', '4', 'images/12.jpg', '1', '10002');
INSERT INTO `travel` VALUES ('202211155', '2号茶场', '好的', '42.00', '0', '123', '泉州', '2022-11-16 09:39:40', '2022-12-11 09:39:42', '2022-11-16 21:40:11', '3', 'images/2.PNG', '1', '10001');
INSERT INTO `travel` VALUES ('202211156', '3号茶场', '好', '444.00', '0', '55', '泉州', '2022-11-16 21:39:40', '2022-12-10 21:39:42', '2022-11-16 21:44:21', '4', 'images/4.jpg', '1', '10001');

-- ----------------------------
-- Table structure for `travelnfo`
-- ----------------------------
DROP TABLE IF EXISTS `travelnfo`;
CREATE TABLE `travelnfo` (
  `oid` int DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `peopleNum` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tid` int DEFAULT NULL,
  `lxpeople` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of travelnfo
-- ----------------------------
INSERT INTO `travelnfo` VALUES ('0', '12', '1212', '121', '202211150', null);
INSERT INTO `travelnfo` VALUES ('0', '1222', '0', '21212', '202211150', null);
INSERT INTO `travelnfo` VALUES ('0', '1222', '121212', '21212', '202211150', null);
INSERT INTO `travelnfo` VALUES ('0', '55', '66', '55', '202211151', null);
INSERT INTO `travelnfo` VALUES ('0', '55', '66', '55', '202211151', null);
INSERT INTO `travelnfo` VALUES ('0', '333', '444', '222', '202211150', null);

-- ----------------------------
-- Table structure for `type`
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `typename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO `type` VALUES ('1', '参观', '茶旅类型');
INSERT INTO `type` VALUES ('2', '体验', '茶旅类型');
INSERT INTO `type` VALUES ('3', '审核', '茶旅/拼好茶');
INSERT INTO `type` VALUES ('4', '开放', '茶旅/拼好茶');
INSERT INTO `type` VALUES ('5', '结束', '茶旅/拼好茶');
INSERT INTO `type` VALUES ('6', '封禁', '茶旅/拼好茶');
INSERT INTO `type` VALUES ('7', '待付款', '订单状态');
INSERT INTO `type` VALUES ('8', '待发货', '订单状态');
INSERT INTO `type` VALUES ('9', '待收货', '订单状态');
INSERT INTO `type` VALUES ('10', '待退款', '订单状态');
INSERT INTO `type` VALUES ('11', '折扣类', '优惠券类型');
INSERT INTO `type` VALUES ('12', '满减类', '优惠券类型');
INSERT INTO `type` VALUES ('13', '未支付', '订单付款状态');
INSERT INTO `type` VALUES ('14', '已支付', '订单付款状态');
INSERT INTO `type` VALUES ('15', '绿茶', '产品类型');
INSERT INTO `type` VALUES ('16', '红茶', '产品类型');
INSERT INTO `type` VALUES ('17', '乌龙茶', '产品类型');
INSERT INTO `type` VALUES ('18', '黄茶', '产品类型');
INSERT INTO `type` VALUES ('19', '黑茶', '产品类型');
INSERT INTO `type` VALUES ('20', '白茶', '产品类型');
INSERT INTO `type` VALUES ('21', '普通用户', '用户角色');
INSERT INTO `type` VALUES ('22', '商家用户', '用户角色');
INSERT INTO `type` VALUES ('23', '平台用户', '用户角色');
INSERT INTO `type` VALUES ('24', '封禁用户', '用户角色');
INSERT INTO `type` VALUES ('25', '未使用', '优惠券状态');
INSERT INTO `type` VALUES ('26', '已使用', '优惠券状态');
INSERT INTO `type` VALUES ('27', '已过期', '优惠券状态');

-- ----------------------------
-- Table structure for `type1`
-- ----------------------------
DROP TABLE IF EXISTS `type1`;
CREATE TABLE `type1` (
  `id` int NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `orderState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `couponType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `payState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `commodityType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `couponState` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of type1
-- ----------------------------
INSERT INTO `type1` VALUES ('0', '参观', '审核', '待付款', '折扣类', '未支付', '绿茶', '普通用户', '未使用');
INSERT INTO `type1` VALUES ('1', '体验', '开放', '待发货', '满减类', '已支付', '红茶', '商家用户', '已使用');
INSERT INTO `type1` VALUES ('2', '', '结束', '待收货', '', null, '乌龙茶', '平台用户', '已过期');
INSERT INTO `type1` VALUES ('3', null, '封禁', '待退款', null, null, '黄茶', '封禁用户', null);
INSERT INTO `type1` VALUES ('4', null, null, null, null, null, '黑茶', null, null);
INSERT INTO `type1` VALUES ('5', null, null, null, null, null, '白茶', null, null);
INSERT INTO `type1` VALUES ('6', null, null, null, null, null, null, null, null);
INSERT INTO `type1` VALUES ('7', null, null, null, null, null, null, null, null);
INSERT INTO `type1` VALUES ('8', null, null, null, null, null, null, null, null);
INSERT INTO `type1` VALUES ('9', null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `sex` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `number` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `role` int DEFAULT NULL,
  `eid` int DEFAULT NULL,
  `lastPasswordResetDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `wx_openid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `eu` (`eid`) USING BTREE,
  CONSTRAINT `eu` FOREIGN KEY (`eid`) REFERENCES `enterprise` (`eid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2022111703 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('22111201', 'lxx', '20', '男', '123', '11234567890', '1234@163.com', '福建省泉州市丰泽区东海街道黎明职业大学', '2022-11-12 16:26:19', '22', '10001', null, null);
INSERT INTO `user` VALUES ('22111401', 'zzx', '22', '男', '123', '12345678910', 'lll@163.com', '福建省泉州市丰泽区东海街道黎明职业大学', '2022-11-14 11:00:09', '22', '10002', null, null);
INSERT INTO `user` VALUES ('2022111701', 'gk', '24', '男', '123', '12345667890', 'yk@yk.com', '福建省泉州市丰泽区东海街道黎明职业大学', '2022-11-17 09:34:03', '21', '10001', '2022-12-03 21:48:13', null);
INSERT INTO `user` VALUES ('2022111702', '微信用户', null, null, 'oxMjq5LqFz7de_6O-MmYA7OJglqM', null, null, null, null, '21', null, '2022-12-04 20:35:46', 'oxMjq5LqFz7de_6O-MmYA7OJglqM');

-- ----------------------------
-- View structure for `mycoupon`
-- ----------------------------
DROP VIEW IF EXISTS `mycoupon`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mycoupon` AS select `coupon`.`cid` AS `cid`,`coupon`.`couponType` AS `couponType`,`coupon`.`couponState` AS `couponState`,`coupon`.`name` AS `name`,`coupon`.`total` AS `total`,`coupon`.`picture` AS `picture`,`coupon`.`discount` AS `discount`,`coupon`.`deduction` AS `deduction`,`coupon`.`condition` AS `condition`,`coupon`.`starttime` AS `starttime`,`coupon`.`endtime` AS `endtime`,`couponlog`.`uid` AS `uid` from (`coupon` join `couponlog`) where (`coupon`.`cid` = `couponlog`.`cid`) ;
